<!DOCTYPE HTML>
<html>
<head>
<link rel="shortcut icon" href="<?php echo base_url();?>assets/images/iqra.gif"  />
<title>
Iqra
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Academy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!-- css files -->
 
  
  
<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url();?>assets/css/team.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css" media="all"/>

<!--notificationstyle-->
<link href="<?php echo base_url();?>assets/notification/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--<link href="<?php echo base_url();?>assets/notification/css/bootstrap.min.css" rel="stylesheet" type="text/css" media="all"/>-->

<!-- /css files -->
<!-- fonts -->
<link href='http://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Nunito:400,300,700' rel='stylesheet' type='text/css'>
<!-- /fonts -->

  
<!-- js files -->
<script src="<?php echo base_url();?>assets/js/modernizr.js"></script>
<!-- /js files -->
</head>
<style>
body.modal-open div.modal-backdrop { 
    z-index: 0; 
}
</style>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
<script src='//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<script async type='text/javascript' src='//cdn.fancybar.net/ac/fancybar.js?zoneid=1502&serve=C6ADVKE&placement=w3layouts' id='_fancybar_js'></script>
<style type='text/css'>  .adsense_fixed{position:fixed;bottom:-8px;width:100%;z-index:999999999999;}.adsense_content{width:720px;margin:0 auto;position:relative;background:#fff;}.adsense_btn_close,.adsense_btn_info{font-size:12px;color:#fff;height:20px;width:20px;vertical-align:middle;text-align:center;background:#000;top:4px;left:4px;position:absolute;z-index:99999999;font-family:Georgia;cursor:pointer;line-height:18px}.adsense_btn_info{left:26px;font-family:Georgia;font-style:italic}.adsense_info_content{display:none;width:260px;height:340px;position:absolute;top:-360px;background:rgba(255,255,255,.9);font-size:14px;padding:20px;font-family:Arial;border-radius:4px;-webkit-box-shadow:0 1px 26px -2px rgba(0,0,0,.3);-moz-box-shadow:0 1px 26px -2px rgba(0,0,0,.3);box-shadow:0 1px 26px -2px rgba(0,0,0,.3)}.adsense_info_content:after{content:'';position:absolute;left:25px;top:100%;width:0;height:0;border-left:10px solid transparent;border-right:10px solid transparent;border-top:10px solid #fff;clear:both}.adsense_info_content #adsense_h3{color:#000;margin:0;font-size:18px!important;font-family:'Arial'!important;margin-bottom:20px!important;}.adsense_info_content .adsense_p{color:#888;font-size:13px!important;line-height:20px;font-family:'Arial'!important;margin-bottom:20px!important;}.adsense_fh5co-team{color:#000;font-style:italic;}</style>
<script>

    $(function() {
      $('.adsense_btn_close').click(function() {
        $(this).closest('.adsense_fixed').css('display', 'none');
      });

      $('.adsense_btn_info').click(function() {
        if ($('.adsense_info_content').is(':visible')) {
          $('.adsense_info_content').css('display', 'none');
        } else {
          $('.adsense_info_content').css('display', 'block');
        }
      });

    });

  </script>
<body>

<div class='adsense_fixed'>
<div class='adsense_content'> 
  
<script async src='//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js'></script>
<!-- ResponsiveW3layouts -->
<!--<ins class='adsbygoogle'
     style='display:block'
     data-ad-client='ca-pub-9153409599391170'
     data-ad-slot='7722137086'
     data-ad-format='auto'></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

<ins class='adsbygoogle'
     style='display:inline-block;width:728px;height:90px'
     data-ad-client='ca-pub-9153409599391170'
     data-ad-slot='6850850687'></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>-->

  </div>
  </div>

<!-- navigation -->
<div class="navbar-wrapper">
    <div class="container">
		<nav class="navbar navbar-inverse navbar-static-top cl-effect-1">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
                    <img src="<?php echo base_url();?>assets/images/new_logo.png" style="margin-left:50px" width="90px" height="50px" class="img-responsive">
					<a class="navbar-brand" href="#"><h3 style="color:green;font-size: 25px;font-weight:bold">Iqra Model High School</h3></a>
				</div>
				<div id="navbar" class="navbar-collapse collapse" >
					<ul class="nav navbar-nav navbar-right" style="margin-left:100px">
						<li class="active"><a href="#">Home</a></li>
						<li><a href="#about">About</a></li>
						<li><a href="#service">Notice_Board</a></li>
						<li><a href="#gallery">Events</a></li>
						<li><a href="#team">Faculty</a></li>
						<li><a href="#contact">Contact</a></li>
						<!--<li><a href="<?php base_url()?>edusol">Login</a></li>-->
						<li>
                                    <a href="#" data-toggle="modal" data-target="#myModal">Login</a>
                                    <!-- Modal -->
                                   <div class="modal" id="myModal" role="dialog">
                                    <div class="modal-dialog">
                                     <!-- Modal content-->
                                      <div class="modal-content">
                                       <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <a class="modal-title btn-lg btn-success" href="<?php base_url()?>edusol">Edusolution</h4></a>
                                        <a class="modal-title btn-lg btn-success" href="">Student Portal</a>
                                      </div>
                                  </li>
					</ul>
				</div>
			</div>
        </nav>
	</div>
</div>
<!-- /navigation -->
<!-- banner section -->
<section class="banner">
	<div class="cover-slider__wrap">
		<ul class="cover-slider">
		<?php
			foreach($slidr_data as $key)
			{?>
			<li class="cover-slider__slide">
			
                  <img src="<?php echo base_url().$key->image;?>" width="100%" height="100%">
						<span class="hide">Alt Tag</span>
						</li>
		<?php 	} ?>
        

				<!--<img src="<?php echo base_url();?>assets/images/banner1.jpg" width="100%" height="100%">
						<span class="hide">Alt Tag</span>-->
			<!--</li>
			<li class="cover-slider__slide">
				<img src="<?php echo base_url();?>assets/images/banner2.jpg" width="100%" height="100%">
				<span class="hide">Alt Tag</span>
			</li>
			<li class="cover-slider__slide">
				<img src="<?php echo base_url();?>assets/images/bner.jpg" width="100%" height="100%">
						<span class="hide">Alt Tag</span>
			</li>-->
		</ul>
	</div>
</section>	
<!-- /banner section -->
<!---728x90--->
<!-- About Section -->
<section class="about-us" id="about">

	<div class="container-fluid">
		<div class="row">	
			<div class="col-lg-6 about-info1 slideanim">
				<img src="<?php echo base_url();?>assets/images/about.jpg" alt="about" class="img-responsive">
			</div>
			<div class="col-lg-6 about-info2 slideanim">
				<div class="about-details">
					<h2 style="color:green">About Us</h2>
					<p>"Keeping pace with the rapidly evolving society of today, demands a lot from an individual."
					  We are providing quality education in Tajweed, Qirat and Hifz-ul-Quran with translation alongwith
					   modern education to our students on modern lines in an atmosphere conducive to their mental, spiritual
					    and physical development.</p>
						<p>"While we assure you that we will do our best to provide your children
						 a conducive environment at School, we expect parents to ensure supporting environment at home as well."</p>
				</div>	
			</div>
		</div>
	</div>	

<!-- /About Section -->
<!---728x90--->
<!-- Service Section -->
<section class="our-services slideanim" id="service">
	<h3 class="text-center slideanim" style="color:green">Notice_Board</h3>
	<p class="text-center slideanim">Iqra Model Hight School Latest Notice Board.</p>
	<div class="container">
		<div class="row">
			<?php $i=0; ?>
			<?php foreach($notice_data as $key)  {  $i++?>
				

			<div class="col-lg-4 col-md-4 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-calendar" aria-hidden="true"></i>	
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info" style="padding-bottom:0px;">
							<h4><?php echo $key->title; ?></h4>
							<p class="serv"><?php echo substr($key->description,0, 50); ?></p>
							<div class="eve-w3lright e1">
					         <a href="#" data-toggle="modal" data-target="#myModal<?php echo $i; ?>"><h5>More</h5></a>
				           </div>
						</div>	
					</div>
				</div>
			</div>
			<div class="modal fade" id="myModal<?php echo $i ?>" tabindex="-1" role="dialog" >
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4><?php echo $key->title; ?></h4>
						<p class="serv" data-toggle="modal" data-target="#myModal5"><?php echo $key->description; ?></p>
									</div>
								</div>
						
							</div>
				       </div><!--end first-->
					   
			<?php }?>
					 
			<!--<div class="col-lg-4 col-md-4 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-cloud" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Our Distinction</h4>
							<p class="serv">Parental guidance through regular Parents Teachers Meetings.</p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-desktop" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>FACILITIES</h4>
							<p class="serv">Transport facility through private contractors is also available for students.</p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-graduation-cap" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Message</h4>
							<p class="serv"> Iqra Model School offer a unique program with
							 strong emphasis on character building.</p>
						</div>	
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-users" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Academic Wing</h4>
							<p class="serv">A Library having 2000 books for staff and students.
							 27 Highly Qualified & Experienced Teaching Staff.</p>
						</div>	
					</div>
				</div>
			</div>-->
			<!--<div class="col-lg-4 col-md-4 col-sm-6 serv-part">
				<div class="row">
					<div class="col-xs-6 slideanim">
						<i class="fa fa-book" aria-hidden="true"></i>
					</div>
					<div class="col-xs-6 slideanim">
						<div class="serv-info">
							<h4>Program Offered</h4>
							<p class="serv"> Iqra Model School is providing Quranic education i.e. Hifz-ul-Quran.</p>
						</div>	
					</div>
				</div>
			</div>-->
		</div>
	</div>
</section>
<!-- /Service Section -->
<!---728x90--->
<!-- Gallery Section -->
<section class="our-gallery" id="gallery">
	<h3 class="text-center slideanim" style="color:green">Our Events</h3>
	<p class="text-center slideanim"></p>
	<div class="container">

<?php foreach($img_data as $key){?>
 <img src="<?php echo base_url().$key->image;?>" width="280px" height="210px" data-darkbox="<?php echo base_url();?>assets/images/gal1.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">

<?php  }?>		

       
		<!--<img src="<?php echo base_url();?>assets/images/gal2.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal2.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal3.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal3.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal4.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal4.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal5.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal5.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal6.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal6.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal7.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal7.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal8.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal8.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal9.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal9.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal10.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal10.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal11.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal11.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">
		<img src="<?php echo base_url();?>assets/images/gal12.jpg"  width="280px" height="210px"  data-darkbox="<?php echo base_url();?>assets/images/gal12.jpg" data-darkbox-description="<b>Lorem Ipsum</b><br>Lorem ipsum dolor sit amet" class="img-responsive slideanim">-->
		
	</div>
</section>	
<!-- /Gallery section -->
<!-- Team -->
<section class="our-team" id="team">
	<h3 class="text-center slideanim" style="color:green"> Our Faculty</h3>
	<p class="text-center slideanim">Iqra Model High School Best Teachers.</p>
	<div class="container">
		<section class="main">
			<ul class="ch-grid">
			<<marquee>
			<?php foreach($pos_data as $key){?>
				<li class="t1">
					<div class="ch-item slideanim">				
						<div class="ch-info">
							<div class="ch-info-front ch-img-1">
								<img class="img-circle" src="<?php echo base_url().$key->image;?>" width="220px" height="193px">
							</div>
							<div class="ch-info-back1">
								<img class="img-circle" src="<?php echo base_url().$key->image;?>" width="220px" height="193px">
								<!--<ul class="social-icons">
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								</ul>-->
							</div>	
						</div>
					</div>
					<!--<h4 class="slideanim"><?php echo $key->name;?></h4>-->
					<!--<p class="team-info slideanim"><?php echo $key->designation;?></p>-->
				</li>
			<?php }?>
			</marquee>
				<!--<li class="t2">
					<div class="ch-item slideanim">
						<div class="ch-info">
							<div class="ch-info-front ch-img-2">
								<img class="img-circle" src="<?php echo base_url();?>assets/images/techer2.jpg" width="220px" height="193px">
							</div>
							<div class="ch-info-back2">
								<img class="img-circle" src="<?php echo base_url();?>assets/images/techer2.jpg" width="220px" height="193px">
								<ul class="social-icons">
									<!--<li><a href="#"><i class="fa fa-facebook"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-twitter"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-linkedin"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-google-plus"></i></a></li>-->
								<!--</ul>
							</div>
						</div>
					</div>
					<h4 class="slideanim">Ali Zafir</h4>
					<p class="team-info slideanim">Director</p>
				</li>-->
				<!--<li class="t3">
					<div class="ch-item slideanim">
						<div class="ch-info">
							<div class="ch-info-front ch-img-3">
								<img class="img-circle" src="<?php echo base_url();?>assets/images/techer3.jpg" width="220px" height="193px">
							</div>
							<div class="ch-info-back3">
								<img class="img-circle" src="<?php echo base_url();?>assets/images/techer3.jpg" width="220px" height="193px">
								<ul class="social-icons">-->
									<!--<li><a href="#"><i class="fa fa-facebook"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-twitter"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-linkedin"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-google-plus"></i></a></li>-->
								<!--</ul>
							</div>
						</div>
					</div>
					<h4 class="slideanim">Nisar Khalid</h4>
					<p class="team-info slideanim">Manager</p>-->
				<!--</li>
				<li class="t4">
					<div class="ch-item slideanim">
						<div class="ch-info">
							<div class="ch-info-front ch-img-4">
								<img class="img-circle" src="<?php echo base_url();?>assets/images/techer4.jpg" width="220px" height="193px">
							</div>
							<div class="ch-info-back4">
								<img class="img-circle" src="<?php echo base_url();?>assets/images/techer4.jpg" width="220px" height="193px">
								<ul class="social-icons">
									<!--<li><a href="#"><i class="fa fa-facebook"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-twitter"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-linkedin"></i></a></li>-->
									<!--<li><a href="#"><i class="fa fa-google-plus"></i></a></li>-->
								<!--</ul>
							</div>
						</div>
					</div>
					<h4 class="slideanim">Sadam Khan</h4>
					<p class="team-info slideanim">Treasurer</p>
				</li>-->
			</ul>
		</section>           
    </div>
</section>	
<!-- /Team -->
<!-- Google Map -->
<section class="map">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 slideanim">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3669452.501531793!2d66.64515489085856!3d26.084234881624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x394cc06b6bc1942b%3A0x2e2056a9c78be82d!2sSindh%2C+Pakistan!5e0!3m2!1sen!2s!4v1493976868487" width="1400" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>	
		</div>
	</div>
</section>
<!-- /Google Map -->
<!-- Contact -->
<section class="contact-us slideanim" id="contact">
	<h3 class="text-center slideanim" style="color:green">Contact Us</h3>
	<p class="text-center slideanim">Please leave a message for us.</p>
	<div class="container">		
		<div class="row">
			<div class="col-lg-5 col-md-5">
				<div class="contact-info">
					<h4 style="color:green">Connect With Us :-</h4>
					<p><strong>Phone :</strong>0300-0000000</p>
					<p><strong>Email :</strong> <a href="mailto:name@example.com">name@example.com</a></p>
					<p class="addr"><strong>Address :</strong>71 Pilgrim Avenue 
Chevy Chase, MD 20815</p>
					<ul class="social-icons2">
						<!--<li><a href="https://www.facebook.com/AlFalahPublicModelHighSchoolUbauro/"><i class="fa fa-facebook"></i></a></li>-->
						<!--<li><a href="#"><i class="fa fa-twitter"></i></a></li>-->
						<!--<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="https://www.gmail.com/tanveer1281@gmail.com"><i class="fa fa-google-plus"></i></a></li>-->
					</ul>
				</div>
			</div>
			<div class="col-lg-7 col-md-7">
				<form action="<?php echo base_url(); ?>Admin/insert_feedback" method="post">
					<div class="row">
						<div class="col-sm-12 form-group slideanim">
							<input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
						</div>
					</div>
					<div class="row email-bar">
						<div class="col-sm-12 form-group slideanim">
							<input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
						</div>
					</div>
					<textarea class="form-control slideanim" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
					<div class="row">
						<div class="col-sm-12 form-group">
							<button class="btn btn-outline1 btn-lg" type="submit">Send</button>
						</div>
					</div>
				</form>			
			</div>
		</div>
	</div>
</section>
<!-- /Contact -->
<!-- Footer Section -->
<section class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<div class="links">
					<a href="#">Home</a>
					<a href="#about">About</a>
					<a href="#service">Services</a>
					<a href="#gallery">Events</a>
					<a href="#team">Faculty</a>
					<a href="#contact">Contact</a>
				</div>
			</div>
			<div class="col-md-3">
				<div class="copyright">
					<p> Design by <strong style="color:green !important">  SoftVilla  </strong> </p>
				</div>
			</div>

			<div class="col-md-4">
				
					 <a href="http://softvilla.com.pk/"><img src="<?php echo base_url();?>assets/images/SoftVillaLogo.png" align="right" width="150px" height="80px"> </a>
				
			</div>

		</div>
	</div>
</section>
<!-- /Footer Section -->
<!-- js files -->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/SmoothScroll.min.js"></script>
<!-- js for banner -->
<script src="<?php echo base_url();?>assets/js/index.js"></script>
<!-- /js for banner -->
<!-- js for gallery -->
<script src="<?php echo base_url();?>assets/js/darkbox.js"></script>
<!-- /js for gallery -->
<!-- js for smooth navigation -->
<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

  // Store hash
  var hash = this.hash;

  // Using jQuery's animate() method to add smooth page scroll
  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
  $('html, body').animate({
    scrollTop: $(hash).offset().top
  }, 900, function(){

    // Add hash (#) to URL when done scrolling (default click behavior)
    window.location.hash = hash;
    });
  });
})
</script>
<!-- /js for smooth navigation -->
<!-- js for sliding animations -->
<script>
$(window).scroll(function() {
  $(".slideanim").each(function(){
    var pos = $(this).offset().top;

    var winTop = $(window).scrollTop();
    if (pos < winTop + 600) {
      $(this).addClass("slide");
    }
  });
});
</script>
<!-- /js for sliding animations -->
<!-- /js files -->
</body>
</html>