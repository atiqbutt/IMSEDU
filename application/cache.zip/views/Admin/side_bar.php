<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        
        
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="<?php echo base_url()?>Admin/dashboard">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            
          </a>
         
        </li>
      
      
        <!--<li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Notice Board</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>index.php/admin/noticeboard"><i class="fa fa-circle-o"></i>View Notice Board</a></li>
            <li><a href="<?php echo base_url()?>index.php/admin/new_noticeboard"><i class="fa fa-circle-o"></i>Add New Notice Board</a></li>
           
          </ul>
        </li>-->
      <!-- <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Admission</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>index.php/admin/admission_fee"><i class="fa fa-circle-o"></i>Admission Fee</a></li>
            <li><a href="<?php echo base_url()?>index.php/admin/admission_criteria"><i class="fa fa-circle-o"></i>Admission Criteria</a></li>
           
          </ul>-->
       

         <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Slider</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>Admin/view_slider"><i class="fa fa-circle-o"></i>View Slider</a></li>
            <li><a href="<?php echo base_url()?>Admin/new_slider"><i class="fa fa-circle-o"></i>Add New Slider</a></li>
           
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Events</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>Admin/gallery"><i class="fa fa-circle-o"></i>View Events</a></li>
            <li><a href="<?php echo base_url()?>Admin/add_gallery"><i class="fa fa-circle-o"></i>Add New Events</a></li>
           
          </ul>
        </li>

         </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Notice_board</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>index.php/admin/Notice"><i class="fa fa-circle-o"></i>View Notice</a></li>
            <li><a href="<?php echo base_url()?>index.php/admin/new_notice"><i class="fa fa-circle-o"></i>Add New Notice</a></li>
           
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Faculty</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url()?>Admin/view_teacher"><i class="fa fa-circle-o"></i>View Faculty</a></li>
            <li><a href="<?php echo base_url()?>Admin/teacher"><i class="fa fa-circle-o"></i>Add New Faculty</a></li>
           
          </ul>
        </li>


        <!--<li><a href="<?php echo base_url()?>index.php/admin/slider"><i class="fa fa-book"></i> <span>Slider</span></a></li>-->

         <li><a href="<?php echo base_url()?>Admin/getfeed_back"><i class="fa fa-book"></i> <span>Feedback</span></a></li>

         <li><a href="<?php echo base_url()?>Admin/log_out"><i class="fa fa-book"></i> <span>Logout</span></a></li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
    <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   
    </div>
  </aside>
          <!-- right col (We are only adding the ID to make the widgets sortable)-->
        <section class="col-lg-5 connectedSortable">

          

          
          </div>
          <!-- /.box -->

        </section>
        <!-- right col -->
      </div>
      <!-- /.row (main row) -->

    </section>
