
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Salary</h3>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Create Salary</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  <div class="form-horizontal form-label-left">
                  <div class="item form-group">
                        <label class="control-label col-md-7 col-sm-7 col-xs-12" for="month"><h2>You cannot created this month salary!</h2> <br><h3>Go Back!</h3>
                        </label>
                  </div>
                  <br>
                  <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-2 col-md-offset-10">
                          <button id="send" type="button" class="btn btn-success"><a href="<?php echo base_url(); ?>salary/creat_salry/" style="color:white;" > Back </a></button>
                        </div>
                      </div>
                    </div>
             
                    </div>


              </div>
            </div>
          </div>
        </div>
        </div>
        <!-- /page content -->
        <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>